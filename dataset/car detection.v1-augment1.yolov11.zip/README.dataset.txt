# car detection > augment1
https://universe.roboflow.com/thworkspace/car-detection-isouk

Provided by a Roboflow user
License: CC BY 4.0

